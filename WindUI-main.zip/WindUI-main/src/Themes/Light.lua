return {
    Name = "Light",
    
    Accent = "#FFFFFF",
    Outline = "#000000",
    
    Text = "#000000",
    PlaceholderText = "#777777"
}