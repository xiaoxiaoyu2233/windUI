return {
    Name = "Dark",
    
    Accent = "#181818",
    Outline = "#FFFFFF",
    
    Text = "#FFFFFF",
    PlaceholderText = "#999999",
}