return {
    Name = "Lime",
    
    Accent = "#ecfccb",  
    Outline = "#FFFFFF", 
    
    Text = "#1a2e05",   
    PlaceholderText = "#999999"
}