# Tab

On this page
[[toc]]

## Tab
### Create Tab
```lua
local Tab = Window:Tab({
    Title = "Main",
    Icon = "folder", -- lucide or rbxassetid
})
```

### Select Tab
```lua
Window:SelectTab(2) -- Number of Tab
```

::: tip INFO
1544 Lucide Icons are used in this UI Library

Last icons update: December 8, 2024
:::